<!DOCTYPE html>
<html>
    
    <head>
        <meta charset="utf-8">
        <title>Modelo</title>
        <!--<link rel="stylesheet" href="css/modelo.css" type="text/css">-->
    </head>
    <body>
        <h1>Título</h1>
        <p>Parágrafo 1</p>
        <p>Parágrafo 2</p>
        <p>Parágrafo 3</p>
        <p><?php echo 1 + 1; ?></p>
    </body>
</html>